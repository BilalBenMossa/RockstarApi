using FakeItEasy;
using RockstarsApi.Application;
using RockstarsApi.Common.Models;
using RockstarsApi.Persistance.UnitOfWork;
using System;
using Xunit;

namespace RockstarsApi.Tests
{
    public class ArtistsTests
    {
        [Fact]
        public void UpdateArtist()
        {
            var fakeUnitOfWork = A.Fake<IUnitOfWork>();

            Artist artist = new Artist
            {
                Id = 99999,
                Name = "TestArtist"
            };

            A.CallTo(() => fakeUnitOfWork.Artist.FindById(A<int>.Ignored)).Returns<Artist>(artist);

            var artistsManager = new ArtistsManager(fakeUnitOfWork);

            artistsManager.InsertOrUpdateArtist(artist);

            A.CallTo(() => fakeUnitOfWork.Artist.FindById(artist.Id)).MustHaveHappened();
            A.CallTo(() => fakeUnitOfWork.Artist.Update(artist)).MustHaveHappened();
            A.CallTo(() => fakeUnitOfWork.Artist.Add(artist)).MustNotHaveHappened();
        }

        [Fact]
        public void AddArtist()
        {
            var fakeUnitOfWork = A.Fake<IUnitOfWork>();

            Artist artist = new Artist
            {
                Id = 99999,
                Name = "TestArtist"
            };

            A.CallTo(() => fakeUnitOfWork.Artist.FindById(A<int>.Ignored)).Returns<Artist>(null);

            var artistsManager = new ArtistsManager(fakeUnitOfWork);

            artistsManager.InsertOrUpdateArtist(artist);

            A.CallTo(() => fakeUnitOfWork.Artist.FindById(artist.Id)).MustHaveHappened();
            A.CallTo(() => fakeUnitOfWork.Artist.Update(artist)).MustNotHaveHappened();
            A.CallTo(() => fakeUnitOfWork.Artist.Add(artist)).MustHaveHappened();
        }

        [Fact]
        public void DeleteValidArtist()
        {
            var fakeUnitOfWork = A.Fake<IUnitOfWork>();

            Artist artist = new Artist
            {
                Id = 99999,
                Name = "TestArtist"
            };

            A.CallTo(() => fakeUnitOfWork.Artist.FindById(A<int>.Ignored)).Returns(artist);

            var artistsManager = new ArtistsManager(fakeUnitOfWork);

            artistsManager.DeleteArtistById(artist.Id);

            A.CallTo(() => fakeUnitOfWork.Artist.FindById(artist.Id)).MustHaveHappened();
            A.CallTo(() => fakeUnitOfWork.Artist.Delete(artist)).MustHaveHappened();
        }

        [Fact]
        public void DeleteInvalidArtist()
        {
            var fakeUnitOfWork = A.Fake<IUnitOfWork>();

            Artist artist = new Artist
            {
                Id = 99999,
                Name = ""
            };

            A.CallTo(() => fakeUnitOfWork.Artist.FindById(A<int>.Ignored)).Returns(null);

            var artistsManager = new ArtistsManager(fakeUnitOfWork);
            artistsManager.DeleteArtistById(artist.Id);

            A.CallTo(() => fakeUnitOfWork.Artist.FindById(artist.Id)).MustHaveHappened();
            A.CallTo(() => fakeUnitOfWork.Artist.Delete(artist)).MustNotHaveHappened();
        }
    }
}
