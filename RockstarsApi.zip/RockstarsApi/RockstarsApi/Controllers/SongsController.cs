﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using RockstarsApi.Application;
using RockstarsApi.Common.Models;

namespace RockstarsApi.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class SongsController : ControllerBase
    {
        private readonly ISongsManager SongsManager;
        private readonly ILogger<SongsController> Logger;

        public SongsController(ISongsManager songsManager, ILogger<SongsController> logger)
        {
            SongsManager = songsManager;
            Logger = logger;
        }

        [HttpGet("GetAllSongs")]
        public IEnumerable<Song> GetSongs()
        {
            return SongsManager.GetAllSongs();
        }

        [HttpGet("GetSongById{id:int}")]
        public IActionResult GetSong([FromRoute] int id)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var songs = SongsManager.GetSongById(id);

                if (songs == null)
                {
                    return NotFound();
                }
                
                return Ok(songs);
            }
            catch (Exception e)
            {
                Logger.LogError(e, "An error has occured while getting songs by id");
                return StatusCode(StatusCodes.Status500InternalServerError, e);
            }
        }

        [HttpGet("GetSongsByName/{name}")]
        public IActionResult GetSongsByName([FromRoute] string name)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                List<Song> songs = SongsManager.GetSongsByName(name);

                if (!songs.Any())
                {
                    return NotFound();
                }

                return Ok(songs);
            }
            catch (Exception e)
            {
                Logger.LogError(e, "An error has occured while getting songs by name");
                return StatusCode(StatusCodes.Status500InternalServerError, e);
            }
        }

        [HttpGet("GetSongsByGenre/{genre}")]
        public IActionResult GetSongsByGenre([FromRoute] string genre)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                List<Song> songs = SongsManager.GetSongsByGenre(genre);

                if (!songs.Any())
                {
                    return NotFound();
                }

                return Ok(songs);
            }
            catch (Exception e)
            {
                Logger.LogError(e, "An error has occured while getting songs by genre");
                return StatusCode(StatusCodes.Status500InternalServerError, e);
            }
        }

        [HttpGet("GetSongsByYear/{startYear},{endYear}")]
        public IActionResult GetSongsByYear([FromRoute] int startYear, [FromRoute] int endYear)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var songs = SongsManager.GetSongsByYear(startYear, endYear);

                if (songs == null)
                {
                    return NotFound();
                }

                return Ok(songs);
            }
            catch (Exception e)
            {
                Logger.LogError(e, "An error has occured while getting songs by year");
                return StatusCode(StatusCodes.Status500InternalServerError, e);
            }
        }

        // POST: api/Songs
        [HttpPost]
        public IActionResult InsertOrUpdateSong([FromBody] Song song)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            SongsManager.InsertOrUpdateSong(song);

            return CreatedAtAction("GetSong", new { id = song.Id }, song);
        }

        // DELETE: api/Songs/5
        [HttpDelete("{id}")]
        public IActionResult DeleteSong([FromRoute] int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (SongsManager.DeleteSongById(id))
                return Ok();
            else
                return NotFound();
        }
    }
}