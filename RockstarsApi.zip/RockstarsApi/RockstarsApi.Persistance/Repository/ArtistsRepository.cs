﻿using Microsoft.EntityFrameworkCore;
using RockstarsApi.Common.Models;
using RockstarsApi.Persistance.Context;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace RockstarsApi.Persistance.Repository
{
    public interface IArtistsRepository : IRepository<Artist>
    {
    }

    public class ArtistsRepository : IArtistsRepository
    {
        private RockstarsApiContext Context;

        public ArtistsRepository(RockstarsApiContext context)
        {
            Context = context;
        }

        public IEnumerable<Artist> List => Context.Artists;

        public void Add(Artist artist)
        {
            Context.Artists.Add(artist);
            Context.Entry(artist).State = EntityState.Added;
            Context.SaveChanges();
        }

        public void Delete(Artist artist)
        {
            Context.Remove(artist);
            Context.Entry(artist).State = EntityState.Deleted;
            Context.SaveChanges();
        }

        public Artist FindById(int Id)
        {
            var result = (from r in Context.Artists where r.Id == Id select r).AsNoTracking().FirstOrDefault();
            return result;
        }

        public void Update(Artist artist)
        {
            Context.Entry(artist).State = EntityState.Modified;
            Context.SaveChanges();
        }
    }
}
