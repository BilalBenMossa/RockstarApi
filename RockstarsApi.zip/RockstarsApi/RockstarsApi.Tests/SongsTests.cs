using FakeItEasy;
using RockstarsApi.Application;
using RockstarsApi.Common.Models;
using RockstarsApi.Persistance.UnitOfWork;
using System;
using Xunit;

namespace RockstarsApi.Tests
{
    public class SongsTests
    {
        [Fact]
        public void UpdateSong()
        {
            var fakeUnitOfWork = A.Fake<IUnitOfWork>();

            Song song = new Song
            {
                Id = 99999,
                Name = "TestSong",
                Album = "TestAlbum",
                Artist = "TestArtist",
                Bpm = 0,
                Duration = 0,
                Genre = "TestGenre",
                Shortname = "TestShortName",
                SpotifyId = "TestId",
                Year = 2010
            };

            A.CallTo(() => fakeUnitOfWork.Song.FindById(A<int>.Ignored)).Returns<Song>(song);

            var songsManager = new SongsManager(fakeUnitOfWork);

            songsManager.InsertOrUpdateSong(song);

            A.CallTo(() => fakeUnitOfWork.Song.FindById(song.Id)).MustHaveHappened();
            A.CallTo(() => fakeUnitOfWork.Song.Update(song)).MustHaveHappened();
            A.CallTo(() => fakeUnitOfWork.Song.Add(song)).MustNotHaveHappened();
        }

        [Fact]
        public void AddSong()
        {
            var fakeUnitOfWork = A.Fake<IUnitOfWork>();

            Song song = new Song
            {
                Id = 99999,
                Name = "TestSong",
                Album = "TestAlbum",
                Artist = "TestArtist",
                Bpm = 0,
                Duration = 0,
                Genre = "TestGenre",
                Shortname = "TestShortName",
                SpotifyId = "TestId",
                Year = 2010
            };

            A.CallTo(() => fakeUnitOfWork.Song.FindById(A<int>.Ignored)).Returns<Song>(null);

            var songsManager = new SongsManager(fakeUnitOfWork);

            songsManager.InsertOrUpdateSong(song);

            A.CallTo(() => fakeUnitOfWork.Song.FindById(song.Id)).MustHaveHappened();
            A.CallTo(() => fakeUnitOfWork.Song.Update(song)).MustNotHaveHappened();
            A.CallTo(() => fakeUnitOfWork.Song.Add(song)).MustHaveHappened();
        }

        [Fact]
        public void DeleteValidSong()
        {
            var fakeUnitOfWork = A.Fake<IUnitOfWork>();

            Song song = new Song
            {
                Id = 99999,
                Name = "TestSong",
                Album = "TestAlbum",
                Artist = "TestArtist",
                Bpm = 0,
                Duration = 0,
                Genre = "TestGenre",
                Shortname = "TestShortName",
                SpotifyId = "TestId",
                Year = 2010
            };

            A.CallTo(() => fakeUnitOfWork.Song.FindById(A<int>.Ignored)).Returns<Song>(song);

            var songsManager = new SongsManager(fakeUnitOfWork);

            songsManager.DeleteSongById(song.Id);

            A.CallTo(() => fakeUnitOfWork.Song.FindById(song.Id)).MustHaveHappened();
            A.CallTo(() => fakeUnitOfWork.Song.Delete(song)).MustHaveHappened();
        }

        [Fact]
        public void DeleteInvalidSong()
        {
            var fakeUnitOfWork = A.Fake<IUnitOfWork>();

            Song song = new Song
            {
                Id = 99999,
                Name = "TestSong",
                Album = "TestAlbum",
                Artist = "TestArtist",
                Bpm = 0,
                Duration = 0,
                Genre = "TestGenre",
                Shortname = "TestShortName",
                SpotifyId = "TestId",
                Year = 2010
            };

            A.CallTo(() => fakeUnitOfWork.Song.FindById(A<int>.Ignored)).Returns<Song>(null);

            var songsManager = new SongsManager(fakeUnitOfWork);

            songsManager.DeleteSongById(song.Id);

            A.CallTo(() => fakeUnitOfWork.Song.FindById(song.Id)).MustHaveHappened();
            A.CallTo(() => fakeUnitOfWork.Song.Delete(song)).MustNotHaveHappened();
        }
    }
}
