﻿using RockstarsApi.Persistance.Context;
using RockstarsApi.Persistance.Repository;
using System;

namespace RockstarsApi.Persistance.UnitOfWork
{
    public interface IUnitOfWork
    {
        IArtistsRepository Artist { get; }
        ISongsRepository Song { get; }
        void Save();
    }

    public class UnitOfWork : IUnitOfWork, IDisposable
    {
        private RockstarsApiContext _repoContext;
        private IArtistsRepository _artist;
        private ISongsRepository _song;

        private bool _disposed = false;

        public UnitOfWork(RockstarsApiContext repositoryContext)
        {
            _repoContext = repositoryContext;
        }

        public IArtistsRepository Artist
        {
            get
            {
                if (_artist == null)
                {
                    _artist = new ArtistsRepository(_repoContext);
                }

                return _artist;
            }
        }

        public ISongsRepository Song
        {
            get
            {
                if (_song == null)
                {
                    _song = new SongsRepository(_repoContext);
                }

                return _song;
            }
        }

        public void Save()
        {
            _repoContext.SaveChanges();
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    _repoContext.Dispose();
                }
            }
            _disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
