﻿using System.Collections.Generic;
using Common;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RockstarsApi.Application;

namespace RockstarsApi.Controllers
{
    [Authorize]
    [ApiController]
    [Route("[controller]")]
    public class UsersController : ControllerBase
    {
        private IUsersManager UsersManager;

        public UsersController(IUsersManager usersManager)
        {
            UsersManager = usersManager;
        }

        [HttpGet]
        public IEnumerable<User> GetAll()
        {
            return UsersManager.GetAllUsers();
        }

        [HttpGet("{id}")]
        public User GetUserById(int id)
        {
            return UsersManager.GetUserById(id);
        }
    }
}
