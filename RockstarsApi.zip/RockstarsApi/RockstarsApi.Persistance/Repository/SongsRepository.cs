﻿using Microsoft.EntityFrameworkCore;
using RockstarsApi.Common.Models;
using RockstarsApi.Persistance.Context;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace RockstarsApi.Persistance.Repository
{
    public interface ISongsRepository : IRepository<Song>
    {
    }

    public class SongsRepository : ISongsRepository
    {
        private RockstarsApiContext Context;

        public SongsRepository(RockstarsApiContext context)
        {
            Context = context;
        }

        public IEnumerable<Song> List => Context.Songs;

        public void Add(Song song)
        {
            Context.Songs.Add(song);
            Context.Entry(song).State = EntityState.Added;
            Context.SaveChanges();
        }

        public void Delete(Song song)
        {
            Context.Remove(song);
            Context.Entry(song).State = EntityState.Deleted;
            Context.SaveChanges();
        }

        public Song FindById(int Id)
        {
            var result = (from r in Context.Songs where r.Id == Id select r).FirstOrDefault();
            return result;
        }

        public void Update(Song song)
        {
            Context.Entry(song).State = EntityState.Modified;
            Context.SaveChanges();
        }
    }
}
