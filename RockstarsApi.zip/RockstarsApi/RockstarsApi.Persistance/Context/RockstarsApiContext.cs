﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using RockstarsApi.Common.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace RockstarsApi.Persistance.Context
{
    public partial class RockstarsApiContext : DbContext
    {
        public RockstarsApiContext()
        {
        }

        public RockstarsApiContext(DbContextOptions<RockstarsApiContext> options, IConfiguration configuration)
            : base(options)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration;

        public virtual DbSet<Artist> Artists { get; set; }
        public virtual DbSet<Song> Songs { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer(Configuration["ConnectionString:RockstarsDB"]);
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            List<Artist> artists = new List<Artist>();

            using (StreamReader r = new StreamReader(Configuration["JsonFiles:Artists"]))
            {
                string json = r.ReadToEnd();
                artists = JsonConvert.DeserializeObject<List<Artist>>(json).Where(x => x.Id != 0).ToList();
            }

            List<Song> songs = new List<Song>();

            using (StreamReader r = new StreamReader(Configuration["JsonFiles:Songs"]))
            {
                string json = r.ReadToEnd();
                songs = JsonConvert.DeserializeObject<List<Song>>(json).Where(x => x.Id != 0).ToList();
            }

            modelBuilder.Entity<Artist>(entity =>
            {
                entity.HasKey(e => e.Id);

                entity.ToTable("Artist");

                entity.HasData(artists);

            });

            modelBuilder.Entity<Song>(entity =>
            {
                entity.HasKey(e => e.Id);

                entity.ToTable("Song");

                entity.Property(e => e.SpotifyId).HasMaxLength(50);

                entity.HasData(songs);
            });
        }
    }
}
