﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace RockstarsApi.Persistance.Migrations
{
    public partial class SecondMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
