﻿using RockstarsApi.Common.Models;
using RockstarsApi.Persistance.UnitOfWork;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RockstarsApi.Application
{
    public interface IArtistsManager
    {
        Artist GetArtistById(int id);
        List<Artist> GetAllArtists();
        List<Artist> GetArtistsByName(string name);
        void InsertOrUpdateArtist(Artist artist);
        bool AddArtist(Artist artist);
        bool UpdateArtist(Artist artist);
        bool DeleteArtistById(int id);
    }

    public class ArtistsManager : IArtistsManager
    {
        private readonly IUnitOfWork UnitOfWork;

        public ArtistsManager(IUnitOfWork unitOfWork)
        {
            UnitOfWork = unitOfWork;
        }

        public Artist GetArtistById(int id)
        {
            return UnitOfWork.Artist.FindById(id);
        }

        public List<Artist> GetAllArtists()
        {
            return UnitOfWork.Artist.List.ToList();
        }

        public List<Artist> GetArtistsByName(string name)
        {
            return GetAllArtists().Where(x => x.Name.ToLower().Contains(name.ToLower())).ToList();
        }

        public void InsertOrUpdateArtist(Artist artist)
        {
            if (ArtistsExists(artist.Id))
                UnitOfWork.Artist.Update(artist);
            else
                UnitOfWork.Artist.Add(artist);
        }

        public bool UpdateArtist(Artist artist)
        {
            if (ArtistsExists(artist.Id))
                UnitOfWork.Artist.Update(artist);
            else
                return false;
            return true;
        }

        public bool AddArtist(Artist artist)
        {
            if (!ArtistsExists(artist.Id))
                UnitOfWork.Artist.Add(artist);
            else
                return false;
            return true;
        }

        private bool ArtistsExists(int id)
        {
            return UnitOfWork.Artist.FindById(id) != null;
        }

        public bool DeleteArtistById(int id)
        {
            var artist = UnitOfWork.Artist.FindById(id);
            if (artist == null)
                return false;

            UnitOfWork.Artist.Delete(artist);

            return true;
        }
    }
}
