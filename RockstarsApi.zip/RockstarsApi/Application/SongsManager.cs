﻿using RockstarsApi.Common.Models;
using RockstarsApi.Persistance.UnitOfWork;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RockstarsApi.Application
{
    public interface ISongsManager
    {
        Song GetSongById(int id);
        List<Song> GetAllSongs();
        List<Song> GetSongsByName(string name);
        List<Song> GetSongsByGenre(string genre);
        List<Song> GetSongsByYear(int startyear, int endyear);
        void InsertOrUpdateSong(Song song);
        bool AddSong(Song song);
        bool UpdateSong(Song song);
        bool DeleteSongById(int id);
    }

    public class SongsManager : ISongsManager
    {
        private readonly IUnitOfWork UnitOfWork;

        public SongsManager(IUnitOfWork unitOfWork)
        {
            UnitOfWork = unitOfWork;
        }
        public Song GetSongById(int id)
        {
            return UnitOfWork.Song.FindById(id);
        }

        public List<Song> GetAllSongs()
        {
            return UnitOfWork.Song.List.ToList();
        }

        public List<Song> GetSongsByName(string name)
        {
            return GetAllSongs().Where(x => x.Name.ToLower().Contains(name.ToLower())).ToList();
        }

        public List<Song> GetSongsByGenre(string genre)
        {
            return GetAllSongs().Where(x => x.Genre.ToLower().Contains(genre.ToLower())).ToList();
        }

        public List<Song> GetSongsByYear(int startyear, int endyear)
        {
            if (startyear == 0 && endyear == 0)
                return null;
            return GetAllSongs().Where(x => x.Year >= startyear && x.Year <= endyear).ToList();
        }

        public void InsertOrUpdateSong(Song song)
        {
            if (SongsExists(song.Id))
                UnitOfWork.Song.Update(song);
            else
                UnitOfWork.Song.Add(song);
        }

        public bool UpdateSong(Song song)
        {
            if (SongsExists(song.Id))
                UnitOfWork.Song.Update(song);
            else
                return false;
            return true;
        }

        public bool AddSong(Song song)
        {
            if (!SongsExists(song.Id))
                UnitOfWork.Song.Add(song);
            else
                return false;
            return true;
        }

        private bool SongsExists(int id)
        {
            return UnitOfWork.Song.FindById(id) != null;
        }

        public bool DeleteSongById(int id)
        {
            var song = UnitOfWork.Song.FindById(id);
            if (song == null)
                return false;

            UnitOfWork.Song.Delete(song);

            return true;
        }
    }
}
