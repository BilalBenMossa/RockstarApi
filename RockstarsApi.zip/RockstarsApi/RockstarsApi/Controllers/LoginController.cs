﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RockstarsApi.Application.Security;
using RockstarsApi.Common.Models;

namespace RockstarsApi.Controllers
{
    [Authorize]
    [ApiController]
    [Route("[controller]")]
    public class LoginController : ControllerBase
    {
        private readonly IAuthenticationService AuthenticationService;

        public LoginController(IAuthenticationService authenticationService)
        {
            AuthenticationService = authenticationService;
        }

        [AllowAnonymous]
        [HttpPost]
        public IActionResult Authenticate([FromBody]Login login)
        {
            var user = AuthenticationService.Authenticate(login.Username, login.Password);

            if (user == null)
                return BadRequest(new { message = "Username or password is incorrect" });

            return Ok(user);
        }
    }
}
