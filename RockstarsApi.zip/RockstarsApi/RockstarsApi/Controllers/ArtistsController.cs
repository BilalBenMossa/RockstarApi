﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NLog;
using RockstarsApi.Application;
using RockstarsApi.Common.Models;

namespace RockstarsApi.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class ArtistsController : ControllerBase
    {
        private readonly IArtistsManager ArtistsManager;
        private readonly ILogger Logger = LogManager.GetCurrentClassLogger();

        public ArtistsController(IArtistsManager artistsManager)
        {
            ArtistsManager = artistsManager;
        }

        [HttpGet("GetAllArtists")]
        public IEnumerable<Artist> GetArtists()
        {
            return ArtistsManager.GetAllArtists();
        }

        [HttpGet("GetArtistById/{id:int}")]
        public IActionResult GetArtist([FromRoute] int id)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var artists = ArtistsManager.GetArtistById(id);

                if (artists == null)
                {
                    return NotFound();
                }

                return Ok(artists);
            }
            catch (Exception e)
            {
                Logger.Error(e, "An error has occured while getting Artist by Id");
                return StatusCode(StatusCodes.Status500InternalServerError, e);
            }
        }

        [HttpGet("GetArtistsByName/{name}")]
        public IActionResult GetArtistsByName([FromRoute] string name)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                List<Artist> artists = ArtistsManager.GetArtistsByName(name);

                if (!artists.Any())
                {
                    return NotFound();
                }

                return Ok(artists);
            }
            catch (Exception e)
            {
                Logger.Error(e, "An error has occured while getting Artist by Name");
                return StatusCode(StatusCodes.Status500InternalServerError, e);
            }
        }

        [HttpPost]
        public IActionResult InsertOrUpdateArtist([FromBody] Artist artist)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                ArtistsManager.InsertOrUpdateArtist(artist);

                return CreatedAtAction("GetArtist", new { id = artist.Id }, artist);
            }
            catch (Exception e)
            {
                Logger.Error(e, "An error has occured while Inserting or Updating Artist");
                return StatusCode(StatusCodes.Status500InternalServerError, e);
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteArtist([FromRoute] int id)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                if (ArtistsManager.DeleteArtistById(id))
                    return Ok();
                else
                    return NotFound();
            }
            catch (Exception e)
            {
                Logger.Error(e, "An error has occured while Deleting Artist");
                return StatusCode(StatusCodes.Status500InternalServerError, e);
            }
        }
    }
}