﻿using Common;
using System;
using System.Collections.Generic;
using System.Linq;

namespace RockstarsApi.Application
{
    public interface IUsersManager
    {
        User Login(string username, string password);
        List<User> GetAllUsers();
        User GetUserById(int id);
    }

    public class UsersManager : IUsersManager
    {
        private List<User> Users = new List<User>
        {
            new User { Id = 1, FirstName = "Bilal", LastName = "The Rockstar", Username = "rockstar" }
        };

        public UsersManager()
        {
        }

        public User Login(string username, string password)
        {
            // Hardcoded, use hash passwords and users in DB for production use.
            return Users.SingleOrDefault(x => x.Username == username && password == "test");
        }

        public List<User> GetAllUsers()
        {
            return Users;
        }

        public User GetUserById(int id)
        {
            return Users.Where(x=>x.Id == id).SingleOrDefault();
        }
    }
}
