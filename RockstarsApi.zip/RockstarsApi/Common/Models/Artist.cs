﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RockstarsApi.Common.Models
{
    public class Artist : IEntity
    {
        public string Name { get; set; }
    }
}
