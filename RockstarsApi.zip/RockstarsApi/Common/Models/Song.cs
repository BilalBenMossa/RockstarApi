﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RockstarsApi.Common.Models
{
    public class Song : IEntity
    {
        public string Name { get; set; }
        public int? Year { get; set; }
        public string Artist { get; set; }
        public string Shortname { get; set; }
        public int? Bpm { get; set; }
        public int? Duration { get; set; }
        public string Genre { get; set; }
        public string SpotifyId { get; set; }
        public string Album { get; set; }
    }
}
