Create a new DB and change the Connectionstring in the Appsettings.
Use 'Update-Database' to create your DB.

Credentials:

Username: rockstar
Password: test

1. Start the application, swagger will startup automatically. 
2. You will first have to login with the above username and password. The WepApi will return a Token.
3. Copy this token.
4. Click on Authorize (on the right upper in swagger)
5. Type in your Token like this: "Bearer <Your_Token>"
6. Now the webapi is completely accessible. 

Ps. You can also f.e. use Postman